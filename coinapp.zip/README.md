# React-ing 3: Coin App

Este proyecto contiene el código para la creación de un componente que realiza acciones CRUD. Es un ejercicio introductorio a los elementos esenciales del "consumo" de una API usada dentro de una aplicación básica de React.

Este este es el sexto entregable que hace parte del Diplomado de Frontend que conforma la ruta de aprendizaje en desarrollo web fullstack.
