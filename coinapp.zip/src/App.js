import { Coin } from './components/Coin';

function App() {
  return (
    <div className="App">
      <Coin />
    </div>
  );
}

export default App;
